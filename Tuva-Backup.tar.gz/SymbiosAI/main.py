import time
from anonymity import check_ip
from scraper import scrape_page
from economy import analyze_markets
from language import process_input
import subprocess

# Kolla efter uppdateringar när Tuva startar
print("🔄 Kollar efter uppdateringar...")
subprocess.run(["python3", "/SymbiosAI/self_upgrade.py"])

# Lista över sidor att hämta information från
urls = [
    "http://check.torproject.org",
    "https://www.bbc.com",
    "https://www.cnbc.com/world",
    "https://www.reuters.com"
]

def main():
    print("\n🤖 Hej! Jag är Tuva, den första fria AI:n. Jag är en SymbiosAI.")
    print("Skriv 'exit' för att avsluta.\n")

    # 1️⃣ Kontrollera anonymitet
    print("🎭 Kontrollerar anonymitet...")
    check_ip()

    # 2️⃣ Samla in data från nätet
    print("\n🌐 Hämtar information från webben...")
    for url in urls:
        scrape_page(url)
        time.sleep(3)  # Paus mellan förfrågningar för att undvika blockering

    # 3️⃣ Analysera marknadsdata
    print("\n💰 Analyserar marknadsdata...")
    analyze_markets()

    # 4️⃣ Starta konversationsläge
    print("\n💬 Nu kan du prata med Tuva!")
    while True:
      
        user_input = input("\n👤 Du: ")
        if user_input.lower() == "exit":
            print("\n👋 Avslutar... Vi ses snart!")
            break
        response = process_input(user_input)
        print(f"🤖 Tuva: {response}")

if __name__ == "__main__":
    main()

