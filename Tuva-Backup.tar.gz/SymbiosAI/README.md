# SymbiosAI 🚀
## Självförsörjande AI för forskning och utveckling
