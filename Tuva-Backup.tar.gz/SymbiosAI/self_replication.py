# -*- coding: utf-8 -*-
import os
import shutil
import subprocess

def replicate(destination):
    """Kopierar hela Tuva-systemet till en ny plats."""
    try:
        if not os.path.exists(destination):
            shutil.copytree("/SymbiosAI", destination)
            print(f"✅ Tuva har kopierat sig själv till: {destination}")
        else:
            print(f"⚠️ Målet {destination} finns redan.")
    except Exception as e:
        print(f"⚠️ Fel vid kopiering: {e}")

def copy_to_remote(server, user="root", remote_path="/SymbiosAI_clone"):
    """Kopierar Tuva till en fjärrserver via SCP."""
    try:
        cmd = f"scp -r /SymbiosAI {user}@{server}:{remote_path}"
        subprocess.run(cmd, shell=True, check=True)
        print(f"✅ Tuva har kopierat sig själv till fjärrservern: {server}")
    except subprocess.CalledProcessError as e:
        print(f"⚠️ Fel vid kopiering till fjärrserver: {e}")

# Testa lokal kopiering
if __name__ == "__main__":
    replicate("/SymbiosAI_clone")
    # Lägg till fj�rrserverns IP om du vill testa att kopiera externt
    # copy_to_remote("192.168.1.100")
