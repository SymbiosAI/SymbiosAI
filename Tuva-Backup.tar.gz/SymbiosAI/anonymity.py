import os
import time

def check_and_start_tor():
    """Kollar om Tor körs och startar det om det behövs."""
    tor_running = os.popen("ps aux | grep '[t]or'").read()
    if not tor_running:
        print("⚠️ Tor är inte igång, startar om...")
        os.system("tor &")
        time.sleep(5)  # Vänta så att Tor hinner starta
    else:
        print("✅ Tor är redan igång.")

# Kör Tor-check vid varje start
check_and_start_tor()
import requests

# Använd Tor-proxyn
proxies = {
    'http': 'socks5h://127.0.0.1:9050',
    'https': 'socks5h://127.0.0.1:9050'
}

def check_ip():
    """Kollar vilken IP-adress AI:n har genom Tor."""
    url = "http://check.torproject.org/api/ip"
    try:
        response = requests.get(url, proxies=proxies)
        print(f"🔍 AI:s nuvarande IP-adress: {response.text}")
    except Exception as e:
        print(f"⚠️ Fel vid anslutning till Tor: {e}")

check_ip()
