import random
import sqlite3

DB_PATH = "/SymbiosAI/symbiosai.db"

def save_fact(key, value):
    """Spara fakta i databasen."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS facts (key TEXT PRIMARY KEY, value TEXT)")
    cursor.execute("INSERT OR REPLACE INTO facts (key, value) VALUES (?, ?)", (key, value))
    conn.commit()
    conn.close()

def get_fact(key):
    """Hämta fakta från databasen."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT value FROM facts WHERE key=?", (key,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else None

def process_input(user_input):
    """Processar användarens input och svarar dynamiskt."""
    user_input = user_input.lower().strip()

    if "jag heter" in user_input:
        name = user_input.replace("jag heter", "").strip()
        save_fact("användarnamn", name)
        return f"Trevligt att träffa dig, {name}!"

    if "vad heter jag" in user_input:
        name = get_fact("användarnamn")
        if name:
            return f"Du heter {name}."
        return "Jag vet inte det än, vad heter du?"

    # Kolla om hon redan har ett svar på frågan
    answer = get_fact(user_input)
    if answer:
        return answer

    # Om hon inte vet, be användaren lära henne
    new_answer = input(f"Jag vet inte svaret på '{user_input}'. Vad borde jag svara? ")
    save_fact(user_input, new_answer)
    return f"Tack! Jag kommer ihåg att svaret på '{user_input}' är '{new_answer}'."
