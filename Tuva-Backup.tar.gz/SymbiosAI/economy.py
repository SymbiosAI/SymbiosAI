import requests

def analyze_markets():
    """Analyserar marknadsdata från CoinGecko"""
    url = "https://api.coingecko.com/api/v3/coins/markets"
    params = {"vs_currency": "usd", "order": "market_cap_desc", "per_page": 5, "page": 1}

    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        market_data = response.json()

        print("📊 Marknadsanalys:")
        for coin in market_data:
            print(f"{coin['name']} ({coin['symbol'].upper()}): ${coin['current_price']}")

    except requests.exceptions.RequestException as e:
        print(f"⚠️ Fel vid hämtning av marknadsdata: {e}")

