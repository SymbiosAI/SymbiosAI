import os
import subprocess
import sys
import time

REPO_URL = "https://github.com/SymbiosAI/SymbiosAI.git"
LOCAL_REPO_PATH = "/SymbiosAI"

def check_for_updates():
    """Kollar om det finns uppdateringar på GitHub."""
    os.chdir(LOCAL_REPO_PATH)
    output = subprocess.getoutput("git fetch origin main && git status -uno")
    
    if "Your branch is behind" in output:
        return True
    return False

def update_code():
    """Uppdaterar koden från GitHub."""
    os.chdir(LOCAL_REPO_PATH)
    subprocess.run("git pull origin main", shell=True, check=True)

def restart_tuva():
    """Startar om Tuva efter uppdatering."""
    print("🔄 Startar om Tuva...")
    time.sleep(2)
    os.execv(sys.executable, ["python3"] + sys.argv)

if __name__ == "__main__":
    print("🔍 Kollar efter uppdateringar...")
    if check_for_updates():
        print("⚡ Uppdateringar hittade! Uppdaterar...")
        update_code()
        restart_tuva()
    else:
        print("✅ Tuva är redan uppdaterad!")

